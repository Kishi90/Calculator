let result = document.getElementById("inputtext");
let number = document.getElementById("inputtext");

let Calculate = (number) => {
    if (number == '%') {
        result.value *= 0.01;
        result.value += '%';
    }
    else {
        result.value += number;
    }
}

let Result = () => {
    try {
        result.value = eval (result.value)
    }

    catch (error) {
        alert ("There is a problem with this operation, please enter a valid input.");
    }
}

function Clear() {
    result.value = " ";
}

function Delete() {
    result.value = result.value.slice(0, -1); 
}