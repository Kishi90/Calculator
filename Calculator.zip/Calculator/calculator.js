let result = document.getElementById("inputtext");

let calculate = (number) => {
    result.value += number;
}

let Result = () => {
    try {
        result.value = eval (result.value)
    }

    catch (error) {
        alert ("There is a problem with this operation, please enter a valid input.");
    }
}

function clear() {
    result.value = " ";
}

function del() {
    result.vaule = result.vaule.slice(0,-1);
}